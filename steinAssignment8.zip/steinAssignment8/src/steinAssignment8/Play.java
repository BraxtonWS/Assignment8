package steinAssignment8;

import java.io.IOException;
import java.util.List;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Play {
	
	GameBoard startBoard;
	
	
	public Play(String[] args) throws IOException {
		if (args.length == 0) {
	//		init(0, 0); 	} else {
                    // //
		int n1,n2;
                BufferedReader stdin = new BufferedReader (new InputStreamReader(System.in));
                        System.out.println("This is the Cracker Barrel Peg Game ");
                       

                        System.out.println("......................................");
			System.out.println("Enter the position of the hole:");

			n1=Integer.parseInt( stdin.readLine());
			n2=Integer.parseInt( stdin.readLine());
                    init(n1,n2);
		}
 else
     init(Integer.parseInt( args[0]),Integer.parseInt( args[1]));
	}
	
	
	private void init(int row, int col) {
		startBoard = new GameBoard(row, col);
	}
	
	//DFS function
	public void DFS() {
		GameTree root = new GameTree(startBoard);
		
		for (GameBoard nextBoard : startBoard.possibleBoards()) {
			GameTree nextNode = new GameTree(nextBoard);
			if (play(nextBoard, nextNode))
				root.addChild(nextNode);
		}
		
                printWinningGame(root);

                //crazy loop
//		while (root.hasChildren())
//                {
//			printWinningGame(root);	
//		}
	}
	
	// to iterate is human, to recurse divine
	
	// print game board at each node on the way down, removing the printed child on the way up
	private void printWinningGame(GameTree parent) {
		System.out.println(parent.getGameBoard());
		
		if (parent.numChildren() > 0) {
			GameTree nextNode = parent.getFirstChild();			
			printWinningGame(nextNode);				// recurse
			if (nextNode.numChildren() == 0)	
				parent.removeFirstChild();
		} else {
			System.out.println("===============================================");
		}
	}
	
	// chase all possible boards
	private boolean play(GameBoard gb, GameTree parent) {
		
		if (gb.finalBoard())	// remember this path was a winning path
			return true;
		
		List<GameBoard> nextBoards = gb.possibleBoards();
			
		boolean found = false;
		
		for (GameBoard nextBoard : nextBoards) {
			GameTree nextNode = new GameTree(nextBoard);
			if (play(nextBoard, nextNode)) {				// recurse
				found = true;
				parent.addChild(nextNode);
			}
		}
		
		return found;
	}
}
