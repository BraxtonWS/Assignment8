package steinAssignment8;

import java.io.IOException;
/*import Play.*;*/


public class PegBoard {

/**
* @param args
*/
public static void main(String[] args) throws IOException {

Play play = new Play(args);

play.DFS();
}
}